"use client"

import Login from "./login/page"

export default function Retorno() {
  return (
    <Login></Login>
  )
}
